import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:meal_review_app/table_names.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'home_page.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(

    url:'https://gwkorhsasqwqwkttqcjp.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd3a29yaHNhc3F3cXdrdHRxY2pwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjc4MTg4NDEsImV4cCI6MjA0MzM5NDg0MX0.g8SR3nDP448Wj2XNrbFTOCeopzNU5eG4ft_7an-YE6I',
    //url: 'https://iyhevaeqtlfxnbajwjjv.supabase.co',
    //anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Iml5aGV2YWVxdGxmeG5iYWp3amp2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjgxMjU2ODMsImV4cCI6MjA0MzcwMTY4M30.ZBQVTTS5VJBLwsmwhjDG9G4tblBNAMNT2DDk0giSHPI',
  );
  runApp( MealApp());
}

final cloud = Supabase.instance.client;

class MealApp extends StatelessWidget {
  const MealApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Meal Review App',
      home:  homePage(),
    );
  }
}