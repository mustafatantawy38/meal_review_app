import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'main.dart';
class homePage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(
           backgroundColor: Colors.blue,
         foregroundColor: Colors.white,
         title: Text('Meal Review App'),
       ),
      body: Center(
        child: ElevatedButton (
          onPressed: ()async{
          final table= await cloud.from('meals').select();
          final js = jsonEncode(table);
          print(js);
          print('Pressed');
          },
          child: Text('Show'),
        ),
      ),
    );
  }




}