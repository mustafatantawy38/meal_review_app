import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class TableNamesScreen extends StatefulWidget {
  @override
  _TableNamesScreenState createState() => _TableNamesScreenState();
}

class _TableNamesScreenState extends State<TableNamesScreen> {
  //List<String>
  var tables = [];
  bool loading = true;
  String errorMessage = '';

  @override
  void initState() {
    super.initState();
    fetchTables();
  }

  Future<void> fetchTables() async {
    final response = await http.get(
      Uri.parse('https://<your-supabase-url>/rest/v1/<your-table-name>'), // Replace with your table name
      headers: {
        'Authorization': 'Bearer <your-api-key>',
        'Accept': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      setState(() {
        tables = data.map((item) => item['tablename']).toList(); // Change 'tablename' based on your actual table structure
        loading = false;
      });
    } else {
      setState(() {
        errorMessage = 'Error: ${response.statusCode}';
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return Center(child: CircularProgressIndicator());
    }

    if (errorMessage.isNotEmpty) {
      return Center(child: Text(errorMessage));
    }

    return ListView.builder(
      itemCount: tables.length,
      itemBuilder: (context, index) {
        return ListTile(
          title: Text(tables[index]),
        );
      },
    );
  }
}
